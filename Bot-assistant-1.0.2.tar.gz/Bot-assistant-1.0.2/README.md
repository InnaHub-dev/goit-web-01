# Bot-assistant

Console app that sorts given folder's content, creates and edits notes and contacts. Could be called from the console by command assist. 